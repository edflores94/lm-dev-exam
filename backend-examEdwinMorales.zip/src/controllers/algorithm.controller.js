import { getPostFixExp, solvePostfix, validateExp } from "../classes/Algorithm.js";

export function evaluateExp(req, res) {
  const { exp } = req.body;
  let postfixRes;

  const isValid = validateExp(exp);
  if (isValid) {
    postfixRes = getPostFixExp(exp);
  } else {
    postfixRes = "Invalid expression";
  }

  try {
    if (postfixRes && isValid) {
      return res.json({
        infix: exp,
        postfix: postfixRes,
        result: solvePostfix(postfixRes)
      });
    } else if (!isValid) {
      res.status(400).json({ message: "The expression " + exp + " is invalid" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Some error ocurred while processing the expression" });
  }
}


