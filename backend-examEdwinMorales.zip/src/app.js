//import the modules
import express, { json } from "express";
import morgan from "morgan";
//importing routes
import algorithmRoutes from "./routes/index";

//initializing the express module
const app = express();

//configuring midlewares
app.use(morgan("dev")); //this plugin is used to view from console the requests
app.use(json()); //understand the data in json format

//routes
app.use("/evaluate", algorithmRoutes);

export default app;
