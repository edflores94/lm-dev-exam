export function getPostFixExp(exp) {
  //declarate one variable for operators and other for stack operators
  let operators = { "+": 1, "-": 1, "*": 2, "/": 2, "^": 3 };
  let stackOperators = [];

  //convert the exp parameter into array
  exp = exp.split("");
  const response = exp.reduce((resp, char) => {
    //put all the caracters in the array
    if (parseFloat(char)) {
      resp.push(char);
    }

    if (char in operators) {
      //if the caracter is an operator, evaluate if the left operator has a high hierarchy than the right operator
      while (peek(stackOperators) in operators && operators[char] <= operators[peek(stackOperators)]) {
        resp.push(stackOperators.pop());
      }
      stackOperators.push(char);
    }

    return resp;
  }, []);

  const finalResp = response.concat(stackOperators.reverse());

  return finalResp.join(" ");
}

export function solvePostfix(postfix) {
  try {
    var outputStack = [];
    postfix = postfix.split(" ");
    for (var i = 0; i < postfix.length; i++) {
      if (!isNaN(postfix[i])) {
        outputStack.push(postfix[i]);
      } else {
        var a = outputStack.pop();
        var b = outputStack.pop();
        if (postfix[i] === "+") {
          outputStack.push(parseInt(a) + parseInt(b));
        } else if (postfix[i] === "-") {
          outputStack.push(parseInt(b) - parseInt(a));
        } else if (postfix[i] === "*") {
          outputStack.push(parseInt(a) * parseInt(b));
        } else if (postfix[i] === "/") {
          outputStack.push(parseInt(b) / parseInt(a));
        } else if (postfix[i] === "^") {
          outputStack.push(Math.pow(parseInt(b), parseInt(a)));
        }
      }
    }
    return outputStack.pop();
  } catch (error) {
    console.error(error);
  }
}

export function validateExp(exp) {
  let resp = true;

  if (exp.length > 1) {
    for (var i = 0; i < exp.length; i++) {
      let word = exp.charAt(i);
      if (word === "(" || word === ")" || exp.charAt(0) === "-" || parseInt(word) < 1) {
        resp = false;
        return;
      }
    }
  } else {
    resp = false;
  }

  return resp;
}

function peek(char) {
  return char[char.length - 1];
}
