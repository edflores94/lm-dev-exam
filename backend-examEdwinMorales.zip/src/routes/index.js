import { Router } from "express";
import { evaluateExp } from "../controllers/algorithm.controller";
const router = Router();

//create a new project
router.post("/", evaluateExp);

export default router;
